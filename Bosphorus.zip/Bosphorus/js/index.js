
// $(document).ready(function() {

// $('.thumb').on('click',function(){
//     var src = $(this).attr('src');
//     $('#product-large-image').attr('src',src);
// });
 
// });


 
 

$(window).scroll(function() {    
    var scroll = $(window).scrollTop();

    if (scroll >= 200) {
        $(".clearHeader").addClass("darkHeader extraclass");
    } else {
        $(".clearHeader").removeClass("darkHeader extraclass");
    }

    if (scroll >= 300) {
      $(".scroll").addClass("extraclass-2");
  } else {
      $(".scroll").removeClass("extraclass-2");
  }

});
 


$('.slick-move-1').slick({
    slidesToShow: 4,
    slidesToScroll: 1,
    arrows : false, 
    dots : false,
    autoplay: true,
    autoplaySpeed: 2000,
    responsive: [
      {
        breakpoint: 992,
        settings: {
          slidesToShow: 4,
          slidesToScroll: 1
        }
      },
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 1
        }
      },
      {
        breakpoint: 576,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1
        }
      }
    ]
  });
  

  $('.scroll').on('click',function(){
    var body = $("html, body");
    body.stop().animate({scrollTop:0}, 500, 'swing');
});